class Array1dkeMatrik {
  public:
    void input_data();
    void proses_data();
    void output_data();

  private:
    string arr[48];
    string matrik[10][3];
    int byk_data,index;
};