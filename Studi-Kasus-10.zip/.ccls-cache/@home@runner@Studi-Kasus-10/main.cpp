#include <iostream>
#include "library/Class.h"
#include "library/Input.h"
#include "library/Output.h"

int main() {
  Peserta* simpul;
  simpul -> input_data();
  simpul -> output_data();
  return 0;
}