void array::input(){
  
  cout<<"Masukkan nama dosen : "; cin>>dosen;
  cout<<"Masukkan mata kuliah : "; cin>>matkul;
  cout<<"Masukkan jumlah mahasiswa : "; cin>>n;
  }