#include <iostream>
#include <fstream>
#include "../library/input.h"

int main() {
    Menu input;
    input.inputData();
    return 0;
}